
/*
 * DataTable function add Student Page
 */

$(function() {
    $("#teacherTable").dataTable();
});
