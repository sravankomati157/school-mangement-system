/*
 * This page create For Written All section jQuery Script
 */

$(document).ready(function($) {

// sectionDatatable initialized
$("#sectionDatatable").dataTable();

jbf.init.getCombo('.classCombo', 'load');
//End documentready funtion
});