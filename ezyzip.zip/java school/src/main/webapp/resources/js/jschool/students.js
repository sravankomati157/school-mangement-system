
/*
 * DataTable function add Student Page
 */

$(function() {
    $("#studentTable").dataTable();
});
