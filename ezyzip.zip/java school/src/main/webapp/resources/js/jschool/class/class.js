/*
 * This page create For Written All class jQuery Script
 */

$(document).ready(function($) {

// classDatatable initialized
$("#classDatatable").dataTable();



//End documentready funtion
});